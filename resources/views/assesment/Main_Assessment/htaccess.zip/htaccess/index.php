<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>summa neram pola</h1>
<?php 
	$black_image_path = "./assets/horse_black.png";
	$image_obj   = imagecreatefrompng(
	'https://media.geeksforgeeks.org/wp-content/uploads/geeksforgeeks-13.png');
	$op_result = imagefilter($image_obj,IMG_FILTER_GRAYSCALE);
	imagepng($image_obj,'converted.png'); //save the image to defined path.
    imagedestroy($image_obj);
	echo $black_image_path;
?>
</body>
</html>